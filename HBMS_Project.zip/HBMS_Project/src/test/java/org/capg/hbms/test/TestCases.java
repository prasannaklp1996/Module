package org.capg.hbms.test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.capg.hbms.dao.*;
import org.capg.hbms.model.*;
import org.capg.hbms.model.Users;
import org.capg.hbms.service.*;
import org.junit.*;
import org.junit.Test;
import org.mockito.*;

public class TestCases {
	
	
	@Mock
    private IRegistrationDao regdao=new RegistrationDaoImpl();
	private IRegistrationService regservice=new RegistrationServiceImpl();
	private IHotelService hotelservice=new HotelServiceImpl();
	
	 IBookingService bookingservice=new BookingServiceImpl();
	@Before
	public void setup()
	{
		//To initialize  proxy object 
		MockitoAnnotations.initMocks(this);
		 regservice=new RegistrationServiceImpl(regdao);
		
		
	}
	@Test
	public void test_login_when_register() {
		 //DemandDraft demandDraft=new DemandDraft("John","Capgemini","infof_capgemini",LocalDate.now(),5000,10,"7287996274");   
		   Users user=new Users(11,"mouli","Employee","Moulya","9876543210","987876","NeraVija","mou@gmail.com");
		    //Dummy Declaration
		       Mockito.when(regservice.createUser(user)).thenReturn(user);
		  //Actual logic Triggered
		 regservice.createUser(user);
		   //mockito Verification 
		    Mockito.verify(regdao).createUser(user);
		    
		
	}
 @Test(expected=NullPointerException.class)
 public void test_book_rooms() {
	 BookingDetails bookroom=new BookingDetails();
	// BookingDetails bookroom=new BookingDetails(200,101,10,LocalDate.now(),LocalDate.of(2018, 10, 26),2,1,300);
	 bookingservice.addbooking(bookroom);
	 
	
	 
 }
 @Test
 public void test_modify_hotels_with_description() {
	 Hotel hotel=new Hotel(2,"hyd","Hotel Taj","abids","40%off",500.0,"9848984898","9090909090","4","taj@gmail.com","taj@taj.com");
	 hotelservice.modifyHotelDescription(hotel.getDescription(),hotel.getHotel_id());
	 
	 
 }
 @Test
 public void test_modify_hotels_with_rate() {
	 Hotel hotel=new Hotel(2,"hyd","Hotel Taj","abids","40%off",500.0,"9848984898","9090909090","4","taj@gmail.com","taj@taj.com");
	 hotelservice.modifyHotelRate(hotel.getAvg_rate_per_night(),hotel.getHotel_id());
	 
	 
 }
 @Test
 public void test_modify_hotels_with_hotelname() {
	 Hotel hotel=new Hotel(2,"hyd","Hotel TajMahal","abids","40%off",500.0,"9848984898","9090909090","4","taj@gmail.com","taj@taj.com");
	 hotelservice.modifyHotelName(hotel.getHotel_name(),hotel.getHotel_id());
	 
	 
 }
}
