package org.capg.hbms.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Set;

import org.capg.hbms.dao.BookingDaoImpl;
import org.capg.hbms.dao.IBookingDao;
import org.capg.hbms.exceptions.InvalidAmountException;
import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.view.UserInteraction;

public class BookingServiceImpl implements IBookingService {
IBookingDao bookingdao=new BookingDaoImpl();
IRoomService roomService=new RoomServiceImpl();


//To add booking into DataBase
	@Override
	public void addbooking(BookingDetails bookingdetails) {
		if(bookingdetails==null)
			throw new NullPointerException();
		else
		bookingdao.addbooking(bookingdetails);
		
	}
	
//To calculate Rate for particular Room
public BookingDetails findAmount(BookingDetails bookingDetails)
{
	
	
	int roomid=bookingDetails.getRoom_id();
	Double roomRate=roomService.roomRate(roomid);
     long days=ChronoUnit.DAYS.between(bookingDetails.getBooked_to(),bookingDetails.getBooked_from());
	if( days==0)
	{
	  days=1;
	}
	Double totalAmount=roomRate*days;
	if(totalAmount<0)
		try {
			throw new InvalidAmountException("Amount is Less than Zero");
		} catch (InvalidAmountException e) {
				e.printStackTrace();
		}
		
	bookingDetails.setAmount(totalAmount);
	return bookingDetails;
}


//To get a list of Bookings done by particular User
public Set<BookingDetails> getBookingDetails(int customerId){
	
	return bookingdao.getBookingDetails(customerId);
}


//List of bookings for specific date
@Override
public List<BookingDetails> getBookings(LocalDate of) {
	
	return bookingdao.getBookings(of);
}

@Override
public List<BookingDetails> getBookingOfHotel(int hotelId) {
	
	return bookingdao.getBookingOfHotel(hotelId);
}

}
