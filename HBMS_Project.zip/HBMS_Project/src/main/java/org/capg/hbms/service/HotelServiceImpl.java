package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.dao.HotelDaoImpl;
import org.capg.hbms.dao.IHotelDao;
import org.capg.hbms.model.Hotel;

public class HotelServiceImpl implements IHotelService {
	IHotelDao hoteldao=new HotelDaoImpl();
	
	//For adding Hotels into DataBase
	@Override
	public void addHotel(Hotel hotel) {
		hoteldao.addHotel(hotel);
		
	}
	
	//To delete Hotels from DataBase
	public void deleteHotel(int hotelid) {
		hoteldao.deleteHotel(hotelid);
		
	}
	
	//To get List of Hotels  for particular City
	@Override
	public List<Hotel> getHotels(String City) {
		
		return hoteldao.getHotels(City);
	}
	
	//To modify Hotel Details
	public void modifyHotelDescription(String str,int hotelid)
	{
		 hoteldao.modifyHotelDescription(str,hotelid);
	}
	
	//To get hotel for particular Hotel_id
	public Hotel getHotel_id(int id)
	{
		return hoteldao.getHotel_id(id);
	}
	
	//Listing all the hotels
	public List<Hotel> getAllHotels() 
	{
		return hoteldao.getAllHotels();
	}
	
	//Modify the hotel name
	public void modifyHotelName(String str,int hotelid)
	{
		hoteldao.modifyHotelName(str, hotelid);
	}
	
	//Modify the hotel rent per night
	public void modifyHotelRate(double rate,int hotelid)
	{
		hoteldao.modifyHotelRate(rate, hotelid);
	}
}
