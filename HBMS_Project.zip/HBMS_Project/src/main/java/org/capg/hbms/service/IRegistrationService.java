package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.model.Users;

public interface IRegistrationService {
	public Users createUser(Users user); 
	public List<Users> getAllUsers();
}
