package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.log4j.Logger;


import org.capg.hbms.model.BookingDetails;


public class BookingDaoImpl implements IBookingDao {
	final static Logger logger=Logger.getLogger(BookingDaoImpl.class);
	@Override
	public void addbooking(BookingDetails bookingdetails) {
		
		
		 String sql="insert into BookingDetails(room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount) values(?,?,?,?,?,?,?);";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setInt(1,(bookingdetails.getRoom_id()));
				statement.setInt(2,(bookingdetails.getUser_id()));
				statement.setDate(3, Date.valueOf(bookingdetails.getBooked_from()));
				statement.setDate(4, Date.valueOf(bookingdetails.getBooked_to()));
				statement.setInt(5,bookingdetails.getNo_of_adults());
				statement.setInt(6,bookingdetails.getNo_of_children() );
				statement.setDouble(7,bookingdetails.getAmount());
				int row=statement.executeUpdate();
				
				if(row>0) {
					System.out.println(row+" bookingdetails added  successfully!");
			logger.info("booking details done successfully");
				}
			} catch (SQLException e) {
				logger.error("sql exception occured when adding booking details");
				e.printStackTrace();
			}
		
		
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
		logger.error("sql exception found");
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<BookingDetails> getBookingDetails(int customerId) {


		Set<BookingDetails> bookDetails = new HashSet<>();
		String sql="Select * from BookingDetails where user_id=?";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1, customerId);
			
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				BookingDetails bookDetail = new BookingDetails();
				
				bookDetail.setBooking_id(resultSet.getInt("booking_id"));
				bookDetail.setUser_id(customerId);
				bookDetail.setRoom_id(resultSet.getInt("room_id"));
				bookDetail.setBooked_from(resultSet.getDate("booked_from").toLocalDate());
				bookDetail.setBooked_to(resultSet.getDate("booked_to").toLocalDate());
				bookDetail.setNo_of_adults(resultSet.getInt("no_of_adults"));
				bookDetail.setNo_of_children(resultSet.getInt("no_of_children"));
				bookDetail.setAmount(resultSet.getDouble("amount"));
				
				bookDetails.add(bookDetail);
				
			}
			return bookDetails;
			
			
			
		} catch (SQLException e) {
			logger.error("invalid user_id entered");
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BookingDetails> getBookings(LocalDate of) {

		List<BookingDetails> bookDetails = new ArrayList<>();
		String sql="Select * from BookingDetails where booked_from=?";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setDate(1, java.sql.Date.valueOf(of));
			
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				BookingDetails bookDetail = new BookingDetails();
				
				bookDetail.setBooking_id(resultSet.getInt("booking_id"));
				bookDetail.setUser_id(resultSet.getInt("user_id"));
				bookDetail.setRoom_id(resultSet.getInt("room_id"));
				bookDetail.setBooked_from(resultSet.getDate("booked_from").toLocalDate());
				bookDetail.setBooked_to(resultSet.getDate("booked_to").toLocalDate());
				bookDetail.setNo_of_adults(resultSet.getInt("no_of_adults"));
				bookDetail.setNo_of_children(resultSet.getInt("no_of_children"));
				bookDetail.setAmount(resultSet.getDouble("amount"));
				
				bookDetails.add(bookDetail);
				
			}
			return bookDetails;
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<BookingDetails> getBookingOfHotel(int hotelId) {

		List<BookingDetails> bookDetails = new ArrayList();
		String sql="select * from bookingdetails where room_id in (select room_id from roomdetails where hotel_id=?)";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1,hotelId );
			
			ResultSet resultSet = statement.executeQuery();
			
			while(resultSet.next()) {
				BookingDetails bookDetail = new BookingDetails();
				
				bookDetail.setBooking_id(resultSet.getInt("booking_id"));
				bookDetail.setUser_id(hotelId);
				bookDetail.setRoom_id(resultSet.getInt("room_id"));
				bookDetail.setBooked_from(resultSet.getDate("booked_from").toLocalDate());
				bookDetail.setBooked_to(resultSet.getDate("booked_to").toLocalDate());
				bookDetail.setNo_of_adults(resultSet.getInt("no_of_adults"));
				bookDetail.setNo_of_children(resultSet.getInt("no_of_children"));
				bookDetail.setAmount(resultSet.getDouble("amount"));
				
				bookDetails.add(bookDetail);
				
			}
			return bookDetails;
			
			
			
		} catch (SQLException e) {
			logger.error("invalid user_id entered");
			e.printStackTrace();
		}
		return null;
	}


}
