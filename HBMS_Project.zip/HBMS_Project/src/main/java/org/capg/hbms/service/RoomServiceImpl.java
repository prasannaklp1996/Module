package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.dao.IRoomDao;
import org.capg.hbms.dao.RoomDaoImpl;
import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.RoomDetails;

public class RoomServiceImpl implements IRoomService{
	IRoomDao roomdao=new RoomDaoImpl();
	
	//Adding room into DataBase
	@Override
	public void addRoom(RoomDetails room) {
		
		roomdao.addRoom(room);
	}
	
	
	//Getting the list of Rooms from DataBase
	@Override
	public List<RoomDetails> getRooms(int hotel_id) {
		
		return  roomdao.getRooms( hotel_id);
	}
	
	//Calculating Room_Rate for one night
	@Override
	public Double roomRate(int roomid) {
		
		return roomdao.roomRate(roomid);
	}
	
	//Updating the availability of Rooms
	@Override
	public void changeAvailability(RoomDetails finalroom) {
	
		roomdao.changeAvailability(finalroom);
	}
	
	//Get roomDetails for particular room_Id
	@Override
	public RoomDetails getRoom_withID(int room_id) {
		// TODO Auto-generated method stub
		return roomdao.getRoom_withID(room_id);
	}
	
	//Adding room in DataBase
	@Override
	public void addroom(RoomDetails room) {
		roomdao.addRoom(room);
		
	}
	
	//Deleting room from DataBase
	@Override
	public void deleteRoom(int roomid) {
	roomdao.deleteRoom(roomid);
		
	}
	
	//Updating the room Availability
	@Override
	public void setAvailability(RoomDetails roomd) {
		
		roomdao.setAvailability(roomd);
	}
	
	//Changing room_Type
	@Override
	public void changeRoomType(RoomDetails roomdetail) {
		roomdao.changeRoomType(roomdetail);
		
	}
	
	
	//Changing room_Cost
	@Override
	public void changeRoomCost(RoomDetails roomdetail) {
		roomdao.changeRoomCost(roomdetail);
		
	}

//To get all rooms
	@Override
	public List<RoomDetails> getAllRooms() {
		
		return roomdao.getAllRooms();
	}

}
