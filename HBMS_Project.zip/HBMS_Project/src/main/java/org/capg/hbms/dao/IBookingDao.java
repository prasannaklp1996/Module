package org.capg.hbms.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.capg.hbms.model.BookingDetails;

public interface IBookingDao {
	
public void addbooking(BookingDetails bookingdetails);
public Set<BookingDetails> getBookingDetails(int customerId);
public List<BookingDetails> getBookings(LocalDate of);
public List<BookingDetails> getBookingOfHotel(int hotelId);

}
