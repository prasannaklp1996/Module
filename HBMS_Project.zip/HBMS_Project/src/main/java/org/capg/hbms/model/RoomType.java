package org.capg.hbms.model;

public enum RoomType {
	Standard_Non_AC,Standard_AC,Executive_AC,Deluxe_AC;
}
