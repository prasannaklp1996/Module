package org.capg.hbms.boot;

import java.util.List;
import java.util.Scanner;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.Users;
import org.capg.hbms.service.BookingServiceImpl;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IBookingService;
import org.capg.hbms.service.IHotelService;
import org.capg.hbms.service.ILoginService;
import org.capg.hbms.service.IRegistrationService;
import org.capg.hbms.service.LoginServiceImpl;
import org.capg.hbms.service.RegistrationServiceImpl;
import org.capg.hbms.view.UserInteraction;

public class HomeScreen {
 
	public static void main(String[] args) {
	 Scanner scanner=new Scanner(System.in); 
	 IRegistrationService regservice=new RegistrationServiceImpl();
	 ILoginService loginService =new LoginServiceImpl();
	 IHotelService hotelservice=new HotelServiceImpl();
	 UserInteraction userInteraction=new UserInteraction();
	 IBookingService bookingService=new BookingServiceImpl(); 
	 String option="";
	 do {
	 Users user=new Users();
	 System.out.println("-------------------------------- Home Screen  -----------------------------");
		System.out.println("1) Register\n2)Login\nEnter your Choice:");
		int choice=scanner.nextInt();
		
		
			
		if(choice==1) {
			user=userInteraction.userRegistration();
			regservice.createUser(user);
		} else if(choice==2) {
			 System.out.println("----------------------- Login Screen  -----------------------------");
			System.out.println("1.Login as Admin");
			System.out.println("2.Login as customer/Employee");
			int choice2=scanner.nextInt();
			switch(choice2)
			{
			case 1:
				 System.out.println("-------------------------    Admin Screen  -----------------------------");
				Users user1=new Users();
				System.out.println("Enter EmailId to login:");
				user1.setEmail(scanner.next());
				System.out.println("Enter password to login:");
				user1.setPassword(scanner.next());
				if(  loginService.getAdmin(user1)!=null);
				{
					AdminScreen admin=new AdminScreen();
				   admin.adminMain();
				}
			
				break;
			case 2:
				 System.out.println("---------------------User Screen-----------------------------");
				Users user2=new Users();
				System.out.println("Enter EmailId to login:");
				user2.setEmail(scanner.next());
				System.out.println("Enter password to login:");
				user2.setPassword(scanner.next());
				Users user3=loginService.getUser(user2);
			
				//System.out.println(user3);
				if(loginService.getUser(user2)!=null)
				{
					boolean cont=false;	
					do {
						cont=false;	
					System.out.println("1.Search for Hotels");
					System.out.println("2.Book Rooms");
					System.out.println("3.Check Booking Details");
					System.out.println("Choose your Option");
					int ch=scanner.nextInt();
					switch(ch)
					{
					case 1:
						System.out.println("Enter the city name:");
						List<Hotel> hotels=hotelservice.getHotels(scanner.next());
						
						if(hotels!=null && !hotels.isEmpty()) {
							userInteraction.printHotels(hotels);
									}
						else
							System.out.println("No hotels are available in the City you entered :(");
						
						System.out.println("Are you sure, you want to Continue to search [y/n]??");
						String choice1=scanner.next();
						if(choice1.charAt(0)=='y'||choice1.charAt(0)=='Y') {
							cont=true;
							break;
						}
						
						break;
					case 2:
						BookingDetails book=userInteraction.bookRooms();
						System.out.println("Are you sure, you want to continue [y/n]??");
						
						String choice3=scanner.next();
						if(choice3.charAt(0)=='y'||choice3.charAt(0)=='Y') {
							cont=true;
							break;
						}
						
					
						break;
					case 3: 
						
						
						userInteraction.printBookingDetails(user3.getUser_id());
                    System.out.println("Are you sure, you want to continue [y/n]??");
						
						String choice4=scanner.next();
						if(choice4.charAt(0)=='y'||choice4.charAt(0)=='Y') {
							cont=true;
							break;
						}
					
						break;
						default:
							System.out.println("Invalid Option!");
							break;
					}
					
				}while(cont==true);
				}
				break;
				default:
					System.out.println("Invalid option");
					break;
			}
			
			
		}else System.out.println("Invalid option");
		
		System.out.println("Do you wish to go to Home Screen [Y|N]");
		option=scanner.next();
	}while(option.charAt(0)=='Y'||option.charAt(0)=='y');	
	 
	 System.out.println("Have a Nice Day!");
	}

}
