package org.capg.hbms.dao;

import java.sql.Connection;
import org.apache.log4j.Logger;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.Users;

public class HotelDaoImpl  implements IHotelDao{
	final static Logger logger=Logger.getLogger(HotelDaoImpl.class);
	@Override
	public void addHotel(Hotel hotel) {
	
		 String sql="insert into hotel(city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax) values(?,?,?,?,?,?,?,?,?,?);";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setString(1,hotel.getCity());
				statement.setString(2,hotel.getHotel_name());
				statement.setString(3, hotel.getAddress());
				statement.setString(4,hotel.getDescription());
				statement.setDouble(5,hotel.getAvg_rate_per_night());
				statement.setString(6,hotel.getPhone_no1());
				statement.setString(7,hotel.getPhone_no2());
				statement.setString(8,hotel.getRating());
				statement.setString(9,hotel.getEmail());
				statement.setString(10,hotel.getFax());

				int row=statement.executeUpdate();
				
				if(row>0) {
					System.out.println(row+" Hotel added  successfully!");
			logger.info("hotel added successfully");
				}
			} catch (SQLException e) {
				logger.error("sql exception while adding hotel details");
				e.printStackTrace();
			}
		
	}
	public void deleteHotel(int hotelid) {
		
		 String sql="delete from hotel where hotel_id=?";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setInt(1, hotelid);
				int count=statement.executeUpdate();
				if(count>0) {
					System.out.println(count+" Hotel deleted  successfully!");
			logger.info("hotel deleted successfully");
				}
				
				
			} catch (SQLException e) {
				logger.error("sql exception while deleting hotel");
				e.printStackTrace();
			}
		
	}
	public void modifyHotelDescription(String str,int hotelid) {
		
		 String sql="Update hotel set description=? where hotel_id=?";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setString(1, str);
				statement.setInt(2, hotelid);
				int count=statement.executeUpdate();
				if(count>0) {
					System.out.println("Description changed successfully!");
			logger.info("hotel updated successfully");
				}
				
			} catch (SQLException e) {
				logger.error("sql exception while updating hotel");
				e.printStackTrace();
			}
		
	}
	public void modifyHotelName(String str,int hotelid) {
		
		 String sql="Update hotel set hotel_name=? where hotel_id=?";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setString(1, str);
				statement.setInt(2, hotelid);
				int count=statement.executeUpdate();
				if(count>0) {
					System.out.println("Hotel Name changed successfully!");
			logger.info("hotel name changed successfully");
				}
				
			} catch (SQLException e) {
				logger.error("sql exception while updating hotel name");
				e.printStackTrace();
			}
		
	}
	public void modifyHotelRate(double rate,int hotelid) {
		
		
		 String sql="Update hotel set avg_rate_per_night=? where hotel_id=?";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setDouble(1, rate);
				statement.setInt(2, hotelid);
				int count=statement.executeUpdate();
				if(count>0) {
					System.out.println("Avg Hotel Rent changed successfully!");
			logger.info("avg hotel rent changed successfully");
				}
				
			} catch (SQLException e) {
				logger.error("sql exception while updating avg_rate");
				e.printStackTrace();
			}
		
	}
	@Override
	public List<Hotel> getHotels(String city) {
		List<Hotel> hotels=new ArrayList<>();
		String sql="select * from hotel where city=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1,city);
		
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				Hotel hotel=new Hotel();
				hotel.setHotel_id(res.getInt(1));
				hotel.setCity(res.getString(2));
				hotel.setHotel_name(res.getString(3));
				hotel.setAddress(res.getString(4));
				hotel.setDescription(res.getString(5));
				hotel.setAvg_rate_per_night(res.getDouble(6));
				hotel.setPhone_no1(res.getString(7));
				hotel.setPhone_no2(res.getString(8));
				hotel.setRating(res.getString(9));
				hotel.setEmail(res.getString(10));
				hotel.setFax(res.getString(11));
				hotels.add(hotel);
			}
			
			
			
		} catch (SQLException e) {
			logger.error("sql exception while getting hotel details");
			e.printStackTrace();
		}
		
		return hotels;
	}
	public List<Hotel> getAllHotels() {
		List<Hotel> hotels=new ArrayList<>();
		String sql="select * from hotel ";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			
		
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				Hotel hotel=new Hotel();
				hotel.setHotel_id(res.getInt(1));
				hotel.setCity(res.getString(2));
				hotel.setHotel_name(res.getString(3));
				hotel.setAddress(res.getString(4));
				hotel.setDescription(res.getString(5));
				hotel.setAvg_rate_per_night(res.getDouble(6));
				hotel.setPhone_no1(res.getString(7));
				hotel.setPhone_no2(res.getString(8));
				hotel.setRating(res.getString(9));
				hotel.setEmail(res.getString(10));
				hotel.setFax(res.getString(11));
				hotels.add(hotel);
			}
			
			
			
		} catch (SQLException e) {
			logger.error("sql exception while getting all hotel details");
			e.printStackTrace();
		}
		
		return hotels;
	}
	public Hotel getHotel_id(int id) {
		
		String sql="select * from hotel where hotel_id=?";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1,id);
		
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				Hotel hotel=new Hotel();
				hotel.setHotel_id(res.getInt(1));
				hotel.setCity(res.getString(2));
				hotel.setHotel_name(res.getString(3));
				hotel.setAddress(res.getString(4));
				hotel.setDescription(res.getString(5));
				hotel.setAvg_rate_per_night(res.getDouble(6));
				hotel.setPhone_no1(res.getString(7));
				hotel.setPhone_no2(res.getString(8));
				hotel.setRating(res.getString(9));
				hotel.setEmail(res.getString(10));
				hotel.setFax(res.getString(11));
				return hotel;
			}
			
			
			
		} catch (SQLException e) {
			logger.error("sql exception while getting hotel details");
			e.printStackTrace();
		}
		
		return null;
	}
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			logger.error("sql exception while connecting to the DB");
			e.printStackTrace();
		}
		return null;
	}

	

}
