package org.capg.hbms.service;

import java.util.List;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.RoomDetails;

public interface IRoomService {
public void addRoom(RoomDetails room);
public List<RoomDetails> getRooms(int hotel_id);
public Double roomRate(int roomid);
public void changeAvailability(RoomDetails finalroom);
public RoomDetails getRoom_withID(int room_id);
public void addroom(RoomDetails room);
public void deleteRoom(int roomid);
public void setAvailability(RoomDetails roomd);
public void changeRoomType(RoomDetails roomdetail);
public void changeRoomCost(RoomDetails roomdetail);
public List<RoomDetails> getAllRooms();
}
